Myokit DataBlock1d Binary File
==============================
This zip file contains simulation data in the form of multiple time series.
Zero-dimensional time series, such as time or a global pace variable are
stored, as well as one-dimensional time series, such as the membrane potential
of a linear sequence of cells, as it varies over time.

This file has the following entries:

header_block1d.txt
------------------
A header file containing the following information (line by line):

  - nt     the number of points in time in each entry
  - nx     the width of each 1d block
  - dtype  the used datatype (either "d" or "f")
  - name   the names of all 0d entries, each on its own line
  - 1      the indication that the 1d entries are starting
  - name   the names of all 1d entries, each on its own line

data.bin
--------
A binary file containing the following data, in the data type specified by the
header, and little-endian:

  - The nt time values
  - All 0d entries
  - All 1d entries, reshaped using numpy order='C'