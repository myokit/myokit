#
# Provides extra libraries on top of Myokit's core.
#
# This file is part of Myokit
#  Copyright 2011-2018 Maastricht University, University of Oxford
#  Licensed under the GNU General Public License v3.0
#  See: http://myokit.org
#
"""
Provides functionality built on Myokit's core.
"""

